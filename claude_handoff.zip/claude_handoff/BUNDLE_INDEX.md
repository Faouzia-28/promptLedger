# Claude Handoff Bundle

This folder is a curated snapshot of the PromptLedger project for report generation.

Start here:
1. README.md
2. DEPLOYMENT.md
3. ENVIRONMENT.md
4. OPERATIONS.md
5. PHASE_3_SUMMARY.md
6. PRODUCTIZATION_BACKLOG.md
7. PROMPTLEDGER_ADVANCED_ROADMAP.md
8. promptledger_implementation_v2.md
9. frontend/AGENTS.md
10. frontend/CLAUDE.md

What is included:
- Core project docs and deployment guides
- Frontend configuration and source folders
- Backend configuration and source folders
- Deployment scripts and templates

What is intentionally excluded:
- Secrets and local env files
- Generated output such as .next, node_modules, __pycache__, and caches
- Zip archives and temporary payload files

If you need a narrower report, use the top-level docs first and then inspect the frontend/ and backend/ folders for implementation details.