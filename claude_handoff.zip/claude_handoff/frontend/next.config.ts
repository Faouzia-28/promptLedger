import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async rewrites() {
    const backendUrl = process.env.BACKEND_INTERNAL_URL || 'http://127.0.0.1:8000';

    return [
      {
        source: '/metrics',
        destination: `${backendUrl}/metrics`,
      },
      {
        source: '/health',
        destination: `${backendUrl}/health`,
      },
      {
        source: '/api/v1/webhooks/:path*',
        destination: `${backendUrl}/webhooks/:path*`,
      },
      {
        source: '/webhooks/:path*',
        destination: `${backendUrl}/webhooks/:path*`,
      },
      {
        source: '/api/v1/:path*',
        destination: `${backendUrl}/api/v1/:path*`,
      },
    ];
  },
};

export default nextConfig;
