<#
Setup helper for local Postgres: creates role 'promptledger' with password 'promptledger'
and the 'promptledger' database, then runs alembic migrations. Prompts for superuser credentials.

Run: powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\setup-local-db.ps1
#>

param()

Write-Host 'This script will create the Postgres role and database required by PromptLedger.' -ForegroundColor Cyan
$pgUser = Read-Host 'Postgres superuser (default: postgres)'
if ([string]::IsNullOrWhiteSpace($pgUser)) { $pgUser = 'postgres' }
$pgPort = 5432
# prefer 5433 if available
try { $probe = Test-NetConnection -ComputerName 'localhost' -Port 5433 -WarningAction SilentlyContinue; if ($probe.TcpTestSucceeded) { $pgPort = 5433 } } catch { }

$secure = Read-Host -AsSecureString "Enter password for Postgres user '$pgUser' (input hidden)"
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
$plain = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)

if (-not (Get-Command psql -ErrorAction SilentlyContinue)) {
  Write-Host "psql not found on PATH. Please install Postgres client or add psql to PATH." -ForegroundColor Red
  exit 1
}

$env:PGPASSWORD = $plain

$createSql = @'
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'promptledger') THEN
    CREATE ROLE promptledger LOGIN PASSWORD 'promptledger';
  ELSE
    ALTER ROLE promptledger WITH PASSWORD 'promptledger';
  END IF;
END
$$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_database WHERE datname = 'promptledger') THEN
    PERFORM dblink_exec('dbname=postgres', 'CREATE DATABASE promptledger OWNER promptledger');
  END IF;
END
$$;
'@

# The above uses dblink_exec to ensure idempotent DB creation across servers; if dblink missing, fallback
try {
  & psql -h localhost -p $pgPort -U $pgUser -d postgres -c "$createSql" 2>&1 | Write-Host
} catch {
  Write-Host 'Failed to run creation SQL via psql. Falling back to simple commands.' -ForegroundColor Yellow
  try {
    & psql -h localhost -p $pgPort -U $pgUser -d postgres -c "CREATE ROLE promptledger LOGIN PASSWORD 'promptledger'" 2>&1 | Write-Host
    & psql -h localhost -p $pgPort -U $pgUser -d postgres -c "CREATE DATABASE promptledger OWNER promptledger" 2>&1 | Write-Host
  } catch {
    Write-Host 'Fallback commands failed. Inspect output above for details.' -ForegroundColor Red
    exit 1
  }
}

# Run alembic
Write-Host 'Running alembic upgrade head' -ForegroundColor Cyan
Push-Location -Path (Join-Path (Split-Path -Parent $PSScriptRoot) 'backend')
$env:DATABASE_URL = "postgresql+asyncpg://promptledger:promptledger@localhost:$pgPort/promptledger"
try {
  & python -m alembic upgrade head | Write-Host
  Write-Host 'Migrations applied.' -ForegroundColor Green
} catch {
  Write-Host 'Alembic upgrade failed — check output above.' -ForegroundColor Red
  Pop-Location
  exit 1
}
Pop-Location

# Cleanup sensitive env
Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
Write-Host 'Local DB setup complete. You can now run the preview helper:' -ForegroundColor Green
Write-Host "powershell -NoProfile -ExecutionPolicy Bypass -File .\local-preview.ps1 -SkipServerStart"
