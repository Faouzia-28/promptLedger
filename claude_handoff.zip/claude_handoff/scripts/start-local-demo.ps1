# Wrapper to start local demo: Docker, DB migrations, backend, frontend, and preview
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\start-local-demo.ps1

param(
  [switch]$ForceFrontend3000
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $scriptDir
Set-Location $root

function Wait-For-Port {
  param($computerName, $port, $timeoutSec=60)
  $end = (Get-Date).AddSeconds($timeoutSec)
  while((Get-Date) -lt $end) {
    try {
      $r = Test-NetConnection -ComputerName $computerName -Port $port -WarningAction SilentlyContinue
      if ($r.TcpTestSucceeded) { return $true }
    } catch { }
    Start-Sleep -Seconds 1
  }
  return $false
}

Write-Host "Starting local Docker services..."
docker compose -f docker-compose.local.yml up -d

# Wait for Postgres on 5433 or 5432
$ports = @(5433,5432)
$dbPort = $null
foreach ($p in $ports) {
  if (Wait-For-Port -computerName 'localhost' -port $p -timeoutSec 30) { $dbPort = $p; break }
}
if (-not $dbPort) { Write-Warning "Postgres not reachable on 5433/5432. Continuing with 5433 assumption."; $dbPort = 5433 }
$env:DATABASE_URL = "postgresql+asyncpg://promptledger:promptledger@localhost:$dbPort/promptledger"
Write-Host "Using DATABASE_URL port $dbPort"

# Try to run optional local setup script if present
if (Test-Path .\scripts\setup-local-db.ps1) {
  try {
    Write-Host "Running scripts/setup-local-db.ps1 (best-effort)..."
    & .\scripts\setup-local-db.ps1
  } catch {
    Write-Warning "setup-local-db.ps1 failed: $($_.Exception.Message) -- continuing"
  }
}

# Run alembic migrations
try {
  Write-Host "Running alembic upgrade head..."
  Push-Location backend
  & c:/python313/python.exe -m alembic upgrade head
  Pop-Location
} catch {
  Write-Warning "Alembic migration failed: $($_.Exception.Message) -- continuing"
}

# Choose backend port (8000 preferred)
function Port-In-Use($port) { return (Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue) -ne $null }
$backendPort = 8000
if (Port-In-Use 8000) { $backendPort = 8001; Write-Host "8000 in use, will start backend on 8001" } else { Write-Host "Will start backend on 8000" }

# Start backend detached
$backendCmd = "& {`$env:DATABASE_URL='$env:DATABASE_URL'; `$env:FRONTEND_URL='http://localhost:3000'; Set-Location -Path 'backend'; c:/python313/python.exe -m uvicorn app.main:app --host 0.0.0.0 --port $backendPort }"
Start-Process powershell.exe -ArgumentList '-NoLogo','-NoProfile','-Command',$backendCmd -WorkingDirectory $root | Out-Null
Write-Host "Started backend (detached) on port $backendPort"

# Start frontend detached
$frontendCmd = "& { Set-Location -Path 'frontend'; npm run dev }"
Start-Process powershell.exe -ArgumentList '-NoLogo','-NoProfile','-Command',$frontendCmd -WorkingDirectory $root | Out-Null
Write-Host "Started frontend (detached)"

# Wait for frontend to appear on port 3000..3010
$foundPort = $null
for ($i=0; $i -lt 60; $i++) {
  for ($p=3000; $p -le 3010; $p++) {
    if (Wait-For-Port -computerName 'localhost' -port $p -timeoutSec 1) {
      # check if /local-preview.html responds
      try {
        $resp = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:$p/local-preview.html" -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($resp -and $resp.StatusCode -eq 200) { $foundPort = $p; break }
      } catch {
        # not responding yet
      }
    }
  }
  if ($foundPort) { break }
  Start-Sleep -Seconds 1
}

if (-not $foundPort) {
  Write-Warning "Could not find frontend local-preview.html on ports 3000-3010. Defaulting to 3000 for opening preview."
  $foundPort = 3000
}

# Register demo user and write preview file pointing to the chosen frontend origin
$demoEmail = "demo_{0}@example.com" -f ([guid]::NewGuid().ToString('N').Substring(0,8))
$demoPassword = 'TestPass123!'
$registerBody = @{ org_name='Local Preview Org'; email=$demoEmail; password=$demoPassword } | ConvertTo-Json
$registerUrl = "http://127.0.0.1:$backendPort/api/v1/auth/register"
try {
  Write-Host "Registering demo user at $registerUrl ..."
  $r = Invoke-RestMethod -Method Post -Uri $registerUrl -ContentType 'application/json' -Body $registerBody -TimeoutSec 30
  $token = $r.access_token
  $userJson = $r.user | ConvertTo-Json -Compress
  $previewDir = Join-Path $root 'frontend\public'
  if (-not (Test-Path $previewDir)) { New-Item -ItemType Directory -Path $previewDir -Force | Out-Null }
  $previewPath = Join-Path $previewDir 'local-preview.html'
  $previewHtml = @"
<!doctype html>
<html lang="en"> 
  <head>
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    <title>PromptLedger preview</title>
  </head>
  <body>
    <script>
      (function () {
        const token = '$token';
        const user = $userJson;
        localStorage.setItem('access_token', token);
        localStorage.setItem('user', JSON.stringify(user));
        window.location.replace(new URL('/overview', window.location.origin).toString());
      })();
    </script>
  </body>
</html>
"@
  Set-Content -Path $previewPath -Value $previewHtml -Encoding UTF8
  Write-Host "Wrote preview to $previewPath"
  Write-Host "Demo account: $demoEmail / $demoPassword"
  Start-Process "http://localhost:$foundPort/local-preview.html"
} catch {
  Write-Warning "Demo registration failed: $($_.Exception.Message)"
  if ($_.Exception.Response -ne $null) {
    try {
      $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
      Write-Host "Response: " + $sr.ReadToEnd()
    } catch { }
  }
}

Write-Host "Wrapper finished. If things didn't work, check frontend and backend logs in their respective terminals."